#!/bin/bash
python model_seq2seq.py $1 $2 $3
